package com.hotmail.frojasg1.applications.fileencoder;

public class FileEncoderException extends Exception
{
	public FileEncoderException( String text )
	{
		super( text );
	}
}
