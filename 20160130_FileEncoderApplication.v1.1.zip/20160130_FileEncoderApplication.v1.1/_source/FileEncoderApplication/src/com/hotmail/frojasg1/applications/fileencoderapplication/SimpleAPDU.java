package com.hotmail.frojasg1.applications.fileencoderapplication;

import com.hotmail.frojasg1.applications.fileencoderapplication.SimpleApplet;
import static java.lang.Thread.sleep;
import javacard.security.Key;
import javacardx.crypto.Cipher;
import javax.smartcardio.ResponseAPDU;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*; 
import java.io.*;  
import java.util.*;
import javacard.security.KeyBuilder;
import javacard.security.RSAPublicKey;
import com.licel.jcardsim.crypto.RSAKeyImpl;
import com.licel.jcardsim.crypto.AssymetricCipherImpl;
import com.licel.jcardsim.crypto.SymmetricCipherImpl;
import javacard.security.CryptoException;
import javacard.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javacard.security.AESKey;

//import javax.crypto.Cipher;
/**
 *
 * @author SURYA PRAKASH MISHRA , BATHINI SRINIAS GOUD , HARSHITH KUMAR SINGH
 *            Uco 448429             Uco 448427           Uco 448412
 * Description : The Code for signature generation on Simulator
 */
public class SimpleAPDU {
    static CardMngr cardManager = new CardMngr();

    private static byte NEW_USER_PIN[] = {(byte) 0x31, (byte) 0x32, (byte) 0x33, (byte) 0x34}; //PIN in decimal 1234
      private static byte NEW_USER_PIN2[] = {(byte) 0x33, (byte) 0x32, (byte) 0x33, (byte) 0x34}; //PIN in decimal 1234

    private static byte APPLET_AID[] = {(byte) 0x4C, (byte) 0x61, (byte) 0x62, (byte) 0x61, (byte) 0x6B,
        (byte) 0x41, (byte) 0x70, (byte) 0x70, (byte) 0x6C, (byte) 0x65, (byte) 0x74};
    private static byte SELECT_SIMPLEAPPLET[] = {(byte) 0x00, (byte) 0xa4, (byte) 0x04, (byte) 0x00, (byte) 0x0b, 
        (byte) 0x4C, (byte) 0x61, (byte) 0x62, (byte) 0x61, (byte) 0x6B,
        (byte) 0x41, (byte) 0x70, (byte) 0x70, (byte) 0x6C, (byte) 0x65, (byte) 0x74};

    private final byte selectCM[] = {
        (byte) 0x00, (byte) 0xa4, (byte) 0x04, (byte) 0x00, (byte) 0x07, (byte) 0xa0, (byte) 0x00, (byte) 0x00,
        (byte) 0x00, (byte) 0x18, (byte) 0x43, (byte) 0x4d};
    byte[] secret ={ (byte)0x01,(byte)0x02,(byte)0x03,(byte)0x04};
    private   Key            m_privateKey = null;
    private   Key            m_publicKey = null;
    private   short          m_apduLogOffset = (short) 0;
    static private Cipher          rsaCipher=null;
    private static  AESKey         m_aesKey = null;
    private static  Cipher         m_encryptCipher_ecb = null;    
    private static  Cipher         m_decryptCipher_ecb = null;
    
    
public static byte[] RSAencrypt(byte[] text) throws Exception
{
byte[] cipherText = new byte[128];
RSAPublicKey pubkey=null;
// get an RSA cipher object and print the provider
short explen=3;
short modlen=128;
short exp_pos=140; //position 140 in the buffer
short mod_pos=10; //position 10 in the buffer
int i=0;
byte[] mod=new byte[128];
byte[] exp=new byte[3];
String pubkeyfile;
pubkeyfile= "pub.key" ;
FileInputStream fos;
fos= new FileInputStream(pubkeyfile);
byte[] ExportedKey = new byte[5000];
fos.read(ExportedKey);
for(i=10;i<138;i++)
{
    mod[i-10]=ExportedKey[i];
  //  System.out.printf("%02x ",ExportedKey[i]);
}
for(i=140;i<143;i++)
{
exp[i-140]=ExportedKey[i];   
//System.out.printf("%02x ",ExportedKey[i]);
}
try
{
rsaCipher = Cipher.getInstance(Cipher.ALG_RSA_PKCS1, false);
pubkey = (RSAPublicKey) KeyBuilder.buildKey(KeyBuilder.TYPE_RSA_PUBLIC, KeyBuilder.LENGTH_RSA_1024, false);
pubkey.setExponent(exp, (short) 0, explen);
pubkey.setModulus(mod,(short) 0, modlen); 
// encrypt the plaintext using the public key
 rsaCipher.init(pubkey, Cipher.MODE_ENCRYPT);  
 try
 {   
 rsaCipher.doFinal(text,(short) 0,(short) text.length ,cipherText,(short) 0); 
 }
 catch (Exception e) {
     e.printStackTrace();
 }
 
}catch (Exception e) {
      e.printStackTrace();
    }
return cipherText;

}
///AES ENCRYPTION FUNCTION
 public static byte[] CLIENT_AESEncrypt(byte[] plain,byte[] key)
     {
      int     i;
      byte[] AESCipher=new byte[16];
      
      m_encryptCipher_ecb = Cipher.getInstance(Cipher.ALG_AES_BLOCK_128_ECB_NOPAD, false);  
      m_aesKey = (AESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_AES, KeyBuilder.LENGTH_AES_256, false); 
      m_aesKey.setKey(key, (short) 0);
      // INIT CIPHERS WITH NEW KEY     
      m_encryptCipher_ecb.init(m_aesKey, Cipher.MODE_ENCRYPT);            
      m_encryptCipher_ecb.doFinal(plain, (short) 0,(short) plain.length, AESCipher, (short) 0);
     return AESCipher;
    }   
 public static byte[] CLIENT_AESDecrypt(byte[] AESCipher,byte[] key)
     {
      int     i;
      byte[] AESPlain=new byte[16];
      
      m_decryptCipher_ecb = Cipher.getInstance(Cipher.ALG_AES_BLOCK_128_ECB_NOPAD, false);  
      m_aesKey = (AESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_AES, KeyBuilder.LENGTH_AES_256, false); 
      m_aesKey.setKey(key, (short) 0);
      // INIT CIPHERS WITH NEW KEY     
      m_decryptCipher_ecb.init(m_aesKey, Cipher.MODE_DECRYPT);            
      m_decryptCipher_ecb.doFinal(AESCipher, (short) 0,(short) AESCipher.length, AESPlain, (short) 0);
     return AESPlain;
    }   
 
//END OAES ENCRYPTION FUNCTION 
public static void apdu_main(char[] array, char[] arr1) {
             try {
             
             String pubkeyfile,counterfile;
             pubkeyfile= "pub.key" ;
             counterfile="COUNTER";
             FileOutputStream fos,fos2;
             fos= new FileOutputStream(pubkeyfile);           
             fos2=new FileOutputStream(counterfile);
             byte[] installData = new byte[10]; // no special install data passed now - can be used to pass initial keys etc.
            cardManager.prepareLocalSimulatorApplet(APPLET_AID, installData, SimpleApplet.class);      
            byte count=0;
            // TODO: prepare proper APDU command
            short additionalDataLen = 16;
            int i;
            byte DataArray[]=new byte[]{0x55,0x56,0x57,0x58,0x59,0x5a,0x5b,0x5c,0x5d,0x5e,0x5f,0x60,0x61,0x62,0x63,0x64};
            byte[]  response,response2 = null;     
  //****1.1 SET  PIN  OFFLINE PHASE 
            int additionalDataLen2 = 4;           
             byte apdu_cp[] = new byte[CardMngr.HEADER_LENGTH + additionalDataLen2];
            apdu_cp[CardMngr.OFFSET_CLA] = (byte) 0xB0;
            apdu_cp[CardMngr.OFFSET_INS] = (byte) 0x56;
            apdu_cp[CardMngr.OFFSET_P1] = (byte) 0x00;
            apdu_cp[CardMngr.OFFSET_P2] = (byte) 0x00;
            apdu_cp[CardMngr.OFFSET_LC] = (byte) additionalDataLen2;
            //Set the FOloowing PIN 1234
            for(i=0;i<4;i++)
            apdu_cp[CardMngr.OFFSET_DATA+i] = NEW_USER_PIN[i];
            response = cardManager.sendAPDUSimulator(apdu_cp);            
            
            
   //****1.2 VERIFY PIN OFFLINE PHASE          
            //****1 SET  PIN  OFFLINE PHASE 
            byte apdu_vp[] = new byte[CardMngr.HEADER_LENGTH + additionalDataLen2];
            apdu_vp[CardMngr.OFFSET_CLA] = (byte) 0xB0;
            apdu_vp[CardMngr.OFFSET_INS] = (byte) 0x55;
            apdu_vp[CardMngr.OFFSET_P1] = (byte) 0x00;
            apdu_vp[CardMngr.OFFSET_P2] = (byte) 0x00;
            apdu_vp[CardMngr.OFFSET_LC] = (byte) additionalDataLen2;
            //Set the FOloowing PIN 1234
            for(i=0;i<4;i++)
            apdu_vp[CardMngr.OFFSET_DATA+i] = NEW_USER_PIN[i];
            response = cardManager.sendAPDUSimulator(apdu_vp);    
            
             //*****3 SET THE PASSPHRASE IN CARD OFFLINE PHASE
    Scanner input = new Scanner(System.in);
    System.out.println("ENTER THE PASSPHRASE TO BE STORED IN CARD SECURELY must be atleast 16 characters..\n");    
   // String passphrase = input.nextLine();
	String passphrase="ABCDEFGHIJKLMNOP";    
	//System.out.printf("%s",passphrase);    
    byte [] Bpassphrase=passphrase.getBytes();
    int additionalDataLen5 = 17;           
             byte apdu_passp[] = new byte[CardMngr.HEADER_LENGTH + additionalDataLen5];
            apdu_passp[CardMngr.OFFSET_CLA] = (byte) 0xB0;
            apdu_passp[CardMngr.OFFSET_INS] = (byte) 0x57;
            apdu_passp[CardMngr.OFFSET_P1] = (byte) 0x00;
            apdu_passp[CardMngr.OFFSET_P2] = (byte) 0x00;
            apdu_passp[CardMngr.OFFSET_LC] = (byte) additionalDataLen5;
            for(i=0;i<16;i++)
            apdu_passp[CardMngr.OFFSET_DATA+i] = Bpassphrase[i];
            apdu_passp[CardMngr.OFFSET_DATA+16]=count;
            response = cardManager.sendAPDUSimulator(apdu_passp);                
            
   //****2 GENERATE RSA PUBLIC AND PRIVATE KEY AND EXPORT PUBLIC KEY TO CLIENT OFF LINE PHASE.
                          
          //  System.out.println("\nGeneration of a RSA Key PAIR and Exporting Public Key to Client PC..\n");
            byte apdu_RSAKEYGEN[] = new byte[CardMngr.HEADER_LENGTH + 1];
            apdu_RSAKEYGEN[CardMngr.OFFSET_CLA] = (byte) 0xB0;
            apdu_RSAKEYGEN[CardMngr.OFFSET_INS] = (byte) 0x59;
            apdu_RSAKEYGEN[CardMngr.OFFSET_P1] = (byte) 0x00;
            apdu_RSAKEYGEN[CardMngr.OFFSET_P2] = (byte) 0x00;
            apdu_RSAKEYGEN[CardMngr.OFFSET_LC] = (byte) 0x1;
            apdu_RSAKEYGEN[CardMngr.OFFSET_DATA] = 0x00;
         //   System.out.println("\n Key generation is Successfull and Generated Key is..\n\n");
             long startSignTime = System.currentTimeMillis();
             //For Simulator
            response = cardManager.sendAPDUSimulator(apdu_RSAKEYGEN); 
            fos.write(response);
            fos.close();
         //   byte[] pubkeyholder = new byte[145];
         //   for(i=0;i<145;i++)
         //       pubkeyholder[i]=response[i];
            long endSignTime = System.currentTimeMillis();
        //    System.out.println("The Time Taken for RSA Key Generation  Simulator   " + (endSignTime- startSignTime) + " milliseconds");
  
               
//****** 4  VERIFY PIN BY SENDING ENCRYPTED PIN TO THE CARD USER PHASE.   
   //****4.1 ENCRYPT THE USER ENTERED PIN WITH RSA PUBLIC KEY
            count++;
            byte[] PIN_HOLD=new byte[5];
            for(i=0;i<4;i++)
                PIN_HOLD[i]=(byte)array[i];
            PIN_HOLD[i]=count;
            byte[] CIPHER_PIN= RSAencrypt(PIN_HOLD);  
        //    byte[] pin = new byte[array.length];

	// for (int m = 0; m < pin.length; m++) {

	//  pin[m] = (byte) array[m];
         // System.out.printf("%s",pin[m]);

	// }
         //  byte[] CIPHER_PIN=RSAencrypt(pin);      
//****4.2 SEND ENCRYPTED PIN TO CARD FOR VERIFICATION          
          int additionalDataLen3 = 128;
            byte apdu_RsaDecrypt[] = new byte[CardMngr.HEADER_LENGTH + additionalDataLen3];
            apdu_RsaDecrypt[CardMngr.OFFSET_CLA] = (byte) 0xB0;
            apdu_RsaDecrypt[CardMngr.OFFSET_INS] = (byte) 0x60;
            apdu_RsaDecrypt[CardMngr.OFFSET_P1] = (byte) 0x00;
            apdu_RsaDecrypt[CardMngr.OFFSET_P2] = (byte) 0x00;
            apdu_RsaDecrypt[CardMngr.OFFSET_LC] = (byte) additionalDataLen3; 
          for(i=0;i<128;i++)
            apdu_RsaDecrypt[CardMngr.OFFSET_DATA+i] = CIPHER_PIN[i];
            startSignTime = System.currentTimeMillis();
             //For Simulator            
            response = cardManager.sendAPDUSimulator(apdu_RsaDecrypt); 
            endSignTime = System.currentTimeMillis();
       //     System.out.println("The Time Taken for Decryption by Simulator   " + (endSignTime- startSignTime) + " milliseconds");
     if((response[0]==-112)&&(response[1]==0))
             {
                System.out.println("The PIN Verification is Successfull");
//*****4 GENERATION OF RANDOM SESSION KEY 
               SecureRandom secureRandomGenerator = SecureRandom.getInstance("SHA1PRNG");
               // 4.1 Get RANDOM AES SESSION KEY 32 BYTES (256 bits) 
               byte[] randomBytes = new byte[32];
               secureRandomGenerator.nextBytes(randomBytes);
               System.out.println("\n The Generated Random Session key is..\n");
               for(i=0;i<32;i++)
               System.out.printf("%02x ",randomBytes[i]);           
   //****4.2 ENCRYPT RANDOM SESSION KEY  WITH RSA PUBLIC KEY
             
               byte[] ENCRYPTED_SESSIONKEY = RSAencrypt(randomBytes);   
               
               System.out.println("\n The ENCRYPTED RANDOM  Session key is..\n");
               for(i=0;i<ENCRYPTED_SESSIONKEY.length;i++)
               System.out.printf("%02x ",ENCRYPTED_SESSIONKEY[i]);
                System.out.println("\n SEND THE ENCRYPTED RANDOM  KS , CARD WILL SEND ENCRYPTED PASS PHRASE ENCRYPTED WITH DECRYPTED SESSION KEY..\n");
   //*****4.3 SEND ENCRYPTED SESSION KEY TO DECRYPT AT CARD 
             
              int additionalDataLen4 = 128;
            byte apdu_RsaKSDecrypt[] = new byte[CardMngr.HEADER_LENGTH + additionalDataLen4];
            apdu_RsaKSDecrypt[CardMngr.OFFSET_CLA] = (byte) 0xB0;
            apdu_RsaKSDecrypt[CardMngr.OFFSET_INS] = (byte) 0x61;
            apdu_RsaKSDecrypt[CardMngr.OFFSET_P1] = (byte) 0x00;
            apdu_RsaKSDecrypt[CardMngr.OFFSET_P2] = (byte) 0x00;
            apdu_RsaKSDecrypt[CardMngr.OFFSET_LC] = (byte) additionalDataLen4; 
          for(i=0;i<128;i++)
            apdu_RsaKSDecrypt[CardMngr.OFFSET_DATA+i] = ENCRYPTED_SESSIONKEY[i];
            startSignTime = System.currentTimeMillis();
             //For Simulator            
            response = cardManager.sendAPDUSimulator(apdu_RsaKSDecrypt); 
            endSignTime = System.currentTimeMillis();
   //*****5 AES ENCRYPTION FUNCTION 
    byte [] ENCPASSPHRASE=new byte[16];
  //  ENCPASSPHRASE = CLIENT_AESEncrypt(Bpassphrase,randomBytes);
    for(i=0;i<16;i++) 
        ENCPASSPHRASE[i]=response[i];
   System.out.println("\n The ENCRYPTED PASSPHRASE RECEIVED FROM CARD IS ..\n");
               for(i=0;i<ENCPASSPHRASE.length;i++)
               System.out.printf("%02x ",ENCPASSPHRASE[i]);
   
  byte [] DECPASSPHRASE = CLIENT_AESDecrypt(ENCPASSPHRASE,randomBytes);
               
               System.out.println("\n The DECRYPTED PASSPHRASE AT CLIENT PC IS..\n");
               for(i=0;i<DECPASSPHRASE.length;i++)
               System.out.printf("%02x ",DECPASSPHRASE[i]);
             String text1 = new String(DECPASSPHRASE, "UTF-8");   // if the charset is UTF-8
  
               array = text1.toCharArray();
             
             }
             else
            {System.out.println("PIN Verification is Failed"); 
            for(int n=0; n<4;n++){
                 arr1[n]=0;
                 }}
     } catch (Exception ex) {
            System.out.println("Exception : " + ex);
        }
   
    }
}
