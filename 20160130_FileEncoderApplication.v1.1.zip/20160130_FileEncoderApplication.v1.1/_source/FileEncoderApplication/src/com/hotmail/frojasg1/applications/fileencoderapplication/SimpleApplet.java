/*
 * PACKAGEID: 4C 61 62 61 6B
 * APPLETID: 4C 61 62 61 6B 41 70 70 6C 65 74
 */
package com.hotmail.frojasg1.applications.fileencoderapplication;

/*
 * Imported packages
 */
// specific import for Javacard API access
import javacard.framework.*;
import javacard.security.*;
import javacardx.crypto.*;

public class SimpleApplet extends javacard.framework.Applet
{
    // MAIN INSTRUCTION CLASS
    final static byte CLA_SIMPLEAPPLET                = (byte) 0xB0;
    final static byte INS_VERIFYPIN                  = (byte) 0x55;
    final static byte INS_SETPIN                     = (byte) 0x56;
    final static byte INS_SETPASSPHRASE              = (byte) 0x57;
    final static byte INS_GEN_RSA_KEY_PAIR            = (byte) 0x59;
    final static byte INS_RSA_PINDECRYPT              = (byte) 0x60;
    final static byte INS_RSA_KSDECRYPT               = (byte) 0x61;
    final static short ARRAY_LENGTH                   = (short) 0xff;
    final static byte  AES_BLOCK_LENGTH               = (short) 0x16;
    final static short SW_BAD_TEST_DATA_LEN          = (short) 0x6680;
    final static short SW_KEY_LENGTH_BAD             = (short) 0x6715;
    final static short SW_CIPHER_DATA_LENGTH_BAD     = (short) 0x6710;
    final static short SW_OBJECT_NOT_AVAILABLE       = (short) 0x6711;
    final static short SW_BAD_PIN                    = (short) 0x6900;
    
    private   AESKey         m_aesKey = null;
    private   Cipher         m_encryptCipher_ecb = null;    
    private   Cipher         m_decryptCipher_ecb = null;
    private   OwnerPIN       m_pin = null;
    private   Signature      m_sign = null;
    private   KeyPair        m_keyPair = null;
    private   Key            m_privateKey = null;
    private   Key            m_publicKey = null;
    private   short          m_apduLogOffset = (short) 0;
    private Cipher          rsaCipher=null;
    private   byte[]         m_passphrase;
// TEMPORARRY ARRAY IN RAM
    private   byte        m_ramArray[] = null;
    private static final short RAM_BUF_SIZE = (short) 260;
    private byte[] ram_buf = null;
    public static final boolean DEF_EXT_APDU = false;
    // PERSISTENT ARRAY IN EEPROM
    private   byte       m_dataArray[] = null;
    private   byte       PPSTOREMEM[]=null;
    private   byte       Counter_memory[]=null;
    /**
     * LabakApplet default constructor
     * Only this class's install method should create the applet object.
     */
    protected SimpleApplet(byte[] buffer, short offset, byte length)
    {
        // data offset is used for application specific parameter.
        // initialization with default offset (AID offset).
        short dataOffset = offset;
        boolean isOP2 = false;

        if(length > 9) {
            // Install parameter detail. Compliant with OP 2.0.1.

            // | size | content
            // |------|---------------------------
            // |  1   | [AID_Length]
            // | 5-16 | [AID_Bytes]
            // |  1   | [Privilege_Length]
            // | 1-n  | [Privilege_Bytes] (normally 1Byte)
            // |  1   | [Application_Proprietary_Length]
            // | 0-m  | [Application_Proprietary_Bytes]

            // shift to privilege offset
            dataOffset += (short)( 1 + buffer[offset]);
            // finally shift to Application specific offset
            dataOffset += (short)( 1 + buffer[dataOffset]);

           // <IF NECESSARY, USE COMMENTS TO CHECK LENGTH >
           // // checks wrong data length
           // if(buffer[dataOffset] !=  <PUT YOUR PARAMETERS LENGTH> )
           //     // return received proprietary data length in the reason
           //     ISOException.throwIt((short)(ISO7816.SW_WRONG_LENGTH + offset + length - dataOffset));

            // go to proprietary data
            dataOffset++;
            //EEPROM ARRAY INITIALIZATION 
            m_dataArray = new byte[ARRAY_LENGTH];
            Util.arrayFillNonAtomic(m_dataArray, (short) 0, ARRAY_LENGTH, (byte) 0);
            
            PPSTOREMEM = new byte[ARRAY_LENGTH];
            Util.arrayFillNonAtomic(PPSTOREMEM, (short) 0, ARRAY_LENGTH, (byte) 0);
            Counter_memory = new byte[ARRAY_LENGTH];
            Util.arrayFillNonAtomic(Counter_memory, (short) 0, ARRAY_LENGTH, (byte) 0);
            // TEMPORARY BUFFER USED FOR FAST OPERATION WITH MEMORY LOCATED IN RAM
            m_ramArray = JCSystem.makeTransientByteArray((short) 260, JCSystem.CLEAR_ON_DESELECT);
            ram_buf = JCSystem.makeTransientByteArray(RAM_BUF_SIZE, JCSystem.CLEAR_ON_DESELECT);
            m_pin = new OwnerPIN((byte) 5, (byte) 4);
            m_pin.update(m_dataArray, (byte) 0, (byte) 4);           
             
            // CREATE RSA KEYS AND PAIR
            m_keyPair = new KeyPair(KeyPair.ALG_RSA_CRT, KeyBuilder.LENGTH_RSA_1024);
            rsaCipher = Cipher.getInstance(Cipher.ALG_RSA_PKCS1, false);
            // CREATE AES KEY OBJECT
            m_aesKey = (AESKey) KeyBuilder.buildKey(KeyBuilder.TYPE_AES, KeyBuilder.LENGTH_AES_256, false); 
            m_encryptCipher_ecb = Cipher.getInstance(Cipher.ALG_AES_BLOCK_128_ECB_NOPAD, false);
            m_decryptCipher_ecb = Cipher.getInstance(Cipher.ALG_AES_BLOCK_128_ECB_NOPAD, false); 
            
           // update flag
            isOP2 = true;

        } else {
           // <IF NECESSARY, USE COMMENTS TO CHECK LENGTH >
           // if(length != <PUT YOUR PARAMETERS LENGTH> )
           //     ISOException.throwIt((short)(ISO7816.SW_WRONG_LENGTH + length));
       }

        // <PUT YOUR CREATION ACTION HERE>

        // register this instance
          register();
    }

    /**
     * Method installing the applet.
     * @param bArray the array constaining installation parameters
     * @param bOffset the starting offset in bArray
     * @param bLength the length in bytes of the data parameter in bArray
     */
    public static void install(byte[] bArray, short bOffset, byte bLength) throws ISOException
    {
        // applet  instance creation 
        new SimpleApplet (bArray, bOffset, bLength);
    }

    /**
     * Select method returns true if applet selection is supported.
     * @return boolean status of selection.
     */
    public boolean select()
    {
        // <PUT YOUR SELECTION ACTION HERE>
        
      return true;
    }

    /**
     * Deselect method called by the system in the deselection process.
     */
    public void deselect()
    {

        // <PUT YOUR DESELECTION ACTION HERE>

        return;
    }

    /**
     * Method processing an incoming APDU.
     * @see APDU
     * @param apdu the incoming APDU
     * @exception ISOException with the response bytes defined by ISO 7816-4
     */
    public void process(APDU apdu) throws ISOException
    {
        // get the APDU buffer
        byte[] apduBuffer = apdu.getBuffer();
        //short dataLen = apdu.setIncomingAndReceive();
        //Util.arrayCopyNonAtomic(apduBuffer, (short) 0, m_dataArray, m_apduLogOffset, (short) (5 + dataLen));
        //m_apduLogOffset = (short) (m_apduLogOffset + 5 + dataLen);

        // ignore the applet select command dispached to the process
        if (selectingApplet())
            return;

        // APDU instruction parser
        if (apduBuffer[ISO7816.OFFSET_CLA] == CLA_SIMPLEAPPLET) {
            switch ( apduBuffer[ISO7816.OFFSET_INS] )
            {
                case INS_SETPIN: SetPIN(apdu); break;
                case INS_SETPASSPHRASE: Setpassphrase(apdu); break;
                case INS_VERIFYPIN: VerifyPIN(apdu); break;
                case INS_GEN_RSA_KEY_PAIR: GenRSAKeyPair(apdu); break;
                case INS_RSA_PINDECRYPT: PINDecryptRSA(apdu);break;
                case INS_RSA_KSDECRYPT: KSDecryptRSA(apdu);break;
                default :
                    // The INS code is not supported by the dispatcher
                    ISOException.throwIt( ISO7816.SW_INS_NOT_SUPPORTED ) ;
                break ;

            }
        }
        else ISOException.throwIt( ISO7816.SW_CLA_NOT_SUPPORTED);
    }
    // VERIFY PIN
     void VerifyPIN(APDU apdu) {
      byte[]    apdubuf = apdu.getBuffer();
      short     dataLen = apdu.setIncomingAndReceive();

      // VERIFY PIN
      if (m_pin.check(apdubuf, ISO7816.OFFSET_CDATA, (byte) dataLen) == false)
      ISOException.throwIt(SW_BAD_PIN);
    }
    
    
  //MODIFIED PIN VERIFY FUNCTION
     void MVerifyPIN(APDU apdu, byte[]PINBUFF) {
       short le = apdu.setOutgoing();
       short pos = 0;
      
       ram_buf[pos++]=PINBUFF[5];
       ram_buf[pos++]=PINBUFF[6];
       ram_buf[pos++]=PINBUFF[7];
       ram_buf[pos++]=PINBUFF[8];
      // VERIFY PIN
      if (m_pin.check(ram_buf, (short) 0, (byte) pos) == false)
      ISOException.throwIt(SW_BAD_PIN);
      
    }
     //END OF MODIFIED  PIN VERIFY 
     // SET PIN
     void SetPIN(APDU apdu) {
      byte[]    apdubuf = apdu.getBuffer();
      short     dataLen = apdu.setIncomingAndReceive();
      // SET NEW PIN
      m_pin.update(apdubuf, ISO7816.OFFSET_CDATA, (byte) dataLen);
    }
     //SET PASSPHRASE FUNCTION      
    void Setpassphrase(APDU apdu) {
      byte[]    apdubuf = apdu.getBuffer();
      short     dataLen = apdu.setIncomingAndReceive();      
      // SET KEY VALUE IN EEPROM
      byte i,C_LOC=16;
      for(i=0;i<16;i++)
      PPSTOREMEM[i]=apdubuf[(byte)(ISO7816.OFFSET_CDATA+i)];    
      Counter_memory[0]=apdubuf[(byte)(ISO7816.OFFSET_CDATA+C_LOC)];
    }   
 //SYMMETRIC CRYPTO IMPLEMENTATION
void AESEncrypt(APDU apdu,byte[] key) {
      short le = apdu.setOutgoing();
      short len=0x10;
      byte i;
      for(i=0;i<16;i++)
      ram_buf[i]=PPSTOREMEM[i];
      // CHECK EXPECTED LENGTH (MULTIPLY OF 16 bytes)
      if ((len % 16) != 0) ISOException.throwIt(SW_CIPHER_DATA_LENGTH_BAD);
      // ENCRYPT INCOMING BUFFER
        m_aesKey.setKey(key, (short) 0);
        m_encryptCipher_ecb.init(m_aesKey, Cipher.MODE_ENCRYPT);
        m_encryptCipher_ecb.doFinal(ram_buf, (short)0, len, m_ramArray, (short) 0);      
     // SEND OUTGOING BUFFER
      apdu.setOutgoingLength(len);
      apdu.sendBytesLong(m_ramArray, (short) 0, len); 
    }
  //ASYMMETRIC CRYPTO IMPLIMENTATION  
    private void PINDecryptRSA(APDU apdu)
     {    
          byte baAPDUBuffer[] = apdu.getBuffer();          
          m_privateKey = m_keyPair.getPrivate();
          short i=0;
         // get APDU data
         apdu.setIncomingAndReceive();                    
          short sLc = (short)(baAPDUBuffer[ISO7816.OFFSET_LC] & 0x00FF);
          if (sLc != 128)
               ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);                          
          rsaCipher.init(m_privateKey, Cipher.MODE_DECRYPT);            
          rsaCipher.doFinal(baAPDUBuffer, ISO7816.OFFSET_CDATA, sLc, baAPDUBuffer, ISO7816.OFFSET_CDATA);
        
          if(baAPDUBuffer[9]>Counter_memory[0])
          {  MVerifyPIN(apdu,baAPDUBuffer);  
             Counter_memory[0]=baAPDUBuffer[9];
          }   
          else
              ISOException.throwIt(SW_BAD_PIN);
     }
    
    private void KSDecryptRSA(APDU apdu)
     {    
          
        if(m_pin.isValidated()== false)
        {
        ISOException.throwIt(SW_BAD_PIN);
        } 
    else
        {         
         byte baAPDUBuffer[] = apdu.getBuffer();          
          m_privateKey = m_keyPair.getPrivate();
          short i=0;
         // get APDU data
         apdu.setIncomingAndReceive();                    
          short sLc = (short)(baAPDUBuffer[ISO7816.OFFSET_LC] & 0x00FF);
          if (sLc != 128)
               ISOException.throwIt(ISO7816.SW_WRONG_LENGTH);
                         
          rsaCipher.init(m_privateKey, Cipher.MODE_DECRYPT);                    
          
          rsaCipher.doFinal(baAPDUBuffer, ISO7816.OFFSET_CDATA, sLc, baAPDUBuffer, (short) 0);
          AESEncrypt(apdu,baAPDUBuffer);       
       }        
     }     
 private void sendRSAPublicKey(APDU apdu, RSAPublicKey key) {
        short le = apdu.setOutgoing();
        short pos = 0;

        ram_buf[pos++] = (byte) 0x7F; // Interindustry template for nesting one set of public key data objects.
        ram_buf[pos++] = (byte) 0x49; // "
        ram_buf[pos++] = (byte) 0x82; // Length field: 3 Bytes.
        ram_buf[pos++] = (byte) 0x01; // Length : 265 Bytes.
        ram_buf[pos++] = (byte) 0x09; // "

        ram_buf[pos++] = (byte) 0x81; // RSA public key modulus tag.
        ram_buf[pos++] = (byte) 0x82; // Length field: 3 Bytes.
        ram_buf[pos++] = (byte) 0x01; // Length: 256 bytes.
        ram_buf[pos++] = (byte) 0x00; // "
        pos += key.getModulus(ram_buf, pos);
        
        ram_buf[pos++] = (byte) 0x82; // RSA public key exponent tag.
        ram_buf[pos++] = (byte) 0x03; // Length: 3 Bytes.
        pos += key.getExponent(ram_buf, pos);
        apdu.setOutgoingLength(pos);
        apdu.sendBytesLong(ram_buf, (short) 0, pos);          
      //  byte[] buffer = apdu.getBuffer();
      //  apdu.setOutgoingAndSend(37, 16);
    }     
    void GenRSAKeyPair(APDU apdu) {
     byte[]    apdubuf = apdu.getBuffer();
     short     dataLen = apdu.setIncomingAndReceive();
     short     signLen = 0;
  /*    if(m_pin.isValidated()== false)
        {
        ISOException.throwIt(SW_BAD_PIN);
        } 
    else
        {  */ 
            // STARTS KEY GENERATION PROCESS
            m_keyPair.genKeyPair();
            // OBTAIN KEY REFERENCES
            m_publicKey = m_keyPair.getPublic();
            m_privateKey = m_keyPair.getPrivate();
            sendRSAPublicKey(apdu, ((RSAPublicKey)(m_keyPair.getPublic())));
      //  }
   }

}

