package com.hotmail.frojasg1.encrypting.pseudorandomgenerator;

public class PseudoRandomGeneratorException extends Exception
{
	public PseudoRandomGeneratorException( String text )
	{
		super(text);
	}
}
