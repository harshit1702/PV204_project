/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hotmail.frojasg1.applications.common.configuration;

/**
 *
 * @author Usuario
 */
public class ConfigurationException extends Exception
{
	public ConfigurationException( String message )
	{
		super( message );
	}
}
