/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hotmail.frojasg1.applications.common.components.internationalization;

/**
 *
 * @author Fran
 */
public class InternException extends Exception
{
  InternException( String description )   { super( description ); }
}
